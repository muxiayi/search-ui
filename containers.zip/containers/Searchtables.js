import React, { Component } from 'react';
import MUIDataTable from "mui-datatables";
import "./containers.css";

//get calendar data dynamicly
var calendar = require('./data/calendar.json');

for(var i = 0; i < calendar.length; i++) {
    var obj = calendar[i];

    console.log("Name: " + obj.first_name + ", " + obj.last_name);
}
//get contacts data dynamicly
var contacts = require('./data/contacts.json');

for(var i = 0; i < contacts.length; i++) {
    var obj = contacts[i];

    console.log("Name: " + obj.first_name + ", " + obj.last_name);
}

//get dropbox data dynamicly
var dropbox = require('./data/dropbox.json');

for(var i = 0; i < dropbox.length; i++) {
    var obj = dropbox[i];

    console.log("Name: " + obj.first_name + ", " + obj.last_name);
}

//get slack data dynamicly
var slack = require('./data/slack.json');

for(var i = 0; i < slack.length; i++) {
    var obj = slack[i];

    console.log("Name: " + obj.first_name + ", " + obj.last_name);
}

//get twitter data dynamicly
var twitter = require('./data/tweet.json');

for(var i = 0; i < twitter.length; i++) {
    var obj = twitter[i];

    console.log("Name: " + obj.first_name + ", " + obj.last_name);
}


export class Searchtables extends Component {
  


  render() {
    //set index for search tables
     const columns = ["id", "title", "invitees", "date"];
     const columns1 = ["id", "path", "title", "shared_with","created"];
     const columns2 = ["id", "name", "company", "emails","phones","last_contact"];
     const columns3 = ["id", "channel", "author", "message","timestamp"];
     const columns4 = ["user", "message","timestamp"];       

     const options = {
            rowsPerPageOptions:[5,10,50],
            hasIndex: true, /* <-- use numbers for rows*/
            searchBox: true, /* <-- search true or false */
            download: false, /* <-- csv download true or false */
            print:false,
            indexColumn: "fname", /* <-- add your data first unique column name for this like _id, i used fname because i don't have a _id field in my array */
            
      };
    return (
      <div>
                                                    
                <MUIDataTable data={contacts} columns={columns2} options={options} title={"Contacts datas"} />

                <MUIDataTable data={dropbox} columns={columns1} options={options} title={"Dropbox datas"} />

                <MUIDataTable data={slack} columns={columns3} options={options} title={"Slacks Slack message/thread"} />

                <MUIDataTable data={calendar} columns={columns} options={options} title={"Calendar entry datas"} />

                <MUIDataTable data={twitter} columns={columns4} options={options} title={"Twitter datas"} />
            
          </div>
        );
    }
  }

export default Searchtables;


