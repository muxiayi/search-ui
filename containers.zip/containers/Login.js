import React, { Component } from 'react';
import InputBase from '@material-ui/core/InputBase';



class Login extends React.Component {
  
    constructor(props) {
        super(props);
        this.state = {
          email: "",
          password: ""
        };
      }

  render() {
      const { email, password } = this.state;

        
      return (
       //create email and password buttons so user can login when they click login button
        <form onSubmit={this.handleSubmit} style={{marginLeft: '1vmax',marginTop: '1vmax'}}>
              
              <InputBase style={{width:'10vmax',fontSize:'1vmax',}}
                name="email"
                type="text"
                placeholder="Enter your email"
                value={email}
                onChange={this.handleChange}
              />
        
              <InputBase style={{marginLeft: '1vmax',width:'10vmax',fontSize:'1vmax'}}
                name="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={this.handleChange}
              />
              
              <button style={{width:'3.5vmax',fontSize:'1vmax',backgroundColor:'#FFFFFF',padding: '0.2vmax 0.2vmax'}} type="submit">Login</button>
      </form>

        );
    }

    handleChange = event => {
    this.setState({
      [event.target.name]: event.target.value
    });
  };

  handleSubmit = event => {
    console.log("Submitting");
    console.log(this.state);
  };
}
  

export default Login;


