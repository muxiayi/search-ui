import React, { Component } from 'react';
import iconsdelete from "./iconsdelete.svg";
import "./containers.css";

//get calendar data dynamicly
var jsonData = require('./data/calendar.json');
//get twitter data dynamicly
var twitterData = require('./data/tweet.json');
//get dropbox data dynamicly
var dropboxData = require('./data/dropbox.json');
//get slack data dynamicly
var slackData = require('./data/slack.json');
//get contacts data dynamicly
var contactsData = require('./data/contacts.json');


//merge all json data files into one
jsonData = jsonData.concat(twitterData);
jsonData = jsonData.concat(dropboxData);
jsonData = jsonData.concat(slackData);
jsonData = jsonData.concat(contactsData);


class Searchall extends Component {

    constructor() {
        super();
        this.state = {
          searchResults : [],
          searchStr : '',
        };

         this.handleSearch = this.handleSearch.bind(this);
         this.handleSubmit = this.handleSubmit.bind(this);
         this.addItem = this.addItem.bind(this);
         this.removeItem = this.removeItem.bind(this);
    }


      addItem(e) {
      // Prevent button click from submitting form
        e.preventDefault();

        // Create variables for our list, the item to add, and our form
        let searchResults = this.state.searchResults;
        const newItem = document.getElementById("addInput");
        const form = document.getElementById("addItemForm");

        // If  input has a value
        if (newItem.value != "") {
          // Add the new item to the end of our list array
          searchResults.push(newItem.value);
          // use that to set the state for list
          this.setState({
            searchResults: searchResults
          });
          // Finally, reset the form
          newItem.classList.remove("is-danger");
          form.reset();
        } 
      }

      removeItem(item) {
        // Put our list into an array
        const searchResults = this.state.searchResults.slice();
        // Check to see if item passed in matches item in array
        searchResults.some((el, i) => {
          if (el === item) {
            // If item matches, remove it from array
            searchResults.splice(i, 1);
            return true;
          }
        });
      }

      //match query and database throng keyword" matching_terms"
      handleSearch(event) {

        this.setState({ searchStr: event.target.value });
        this.state.searchResults = [];

        //add all json datas to search results
        if( this.state.searchStr.length > 1){
          for(let i=0; i < jsonData.length; i++){
            for(let j=0; j< jsonData[i].matching_terms.length; j++){
              if( jsonData[i].matching_terms[j].toLowerCase().indexOf(this.state.searchStr.toLowerCase()) !== -1){   
                //check if room is already in the result
                if( !this.state.searchResults.includes(jsonData[i].id))
                  this.state.searchResults.push([
                    jsonData[i].id,' ' ,' ' ,jsonData[i].name,' ' ,' ' ,jsonData[i].user,'  ' ,' ' ,
                    jsonData[i].company, ' ',' ' ,jsonData[i].email, ' ',' ' ,jsonData[i].message, ' ',' ' ,jsonData[i].phones,' ' ,' ' ,
                    jsonData[i].last_contact,' ' ,' ' ,jsonData[i].path,' ' ,' ' ,jsonData[i].title,' ' ,' ' ,jsonData[i].shared_with,' ' ,' ' ,
                    jsonData[i].created,' ' ,' ' ,jsonData[i].channel,' ' ,' ' ,jsonData[i].author,' ' ,' ' ,jsonData[i].timestamp,' ' ,' ' ,jsonData[i].invitees,' ' ,' ' ,
                    ,jsonData[i].date,
                    ]);
              }
            }
          }
        }    

      }

      //handle summit
       handleSubmit(event) {
          event.preventDefault();
      }
         

    render() {    
         
        return (
           
          <div>
             

             <div > 
                <div style={{marginLeft:'17vmax'}} >       
                  <form onSubmit={this.handleSubmit}>                
                    <input type="text" value={this.state.searchStr} onChange={this.handleSearch} placeholder="Search items..."/>
                    <button onClick={this.handleSearch} > Clear </button>
                  </form>
                </div>

                
                      <section className="section">
                        <List items={this.state.searchResults} delete={this.removeItem} />
                      </section>

                    <p style={{marginLeft: '-8vmax',marginTop: '3.5vmax'}}> Taking notes? Add your itmes here!</p>
                    <section className="section" style={{ marginBottom: '1vmax',marginTop: '-1.5vmax', marginLeft: '17vmax'}}>
                        <form className="form" id="addItemForm">
                          <input
                            type="text"
                            className="input"
                            id="addInput"
                            placeholder="Add your notes here..."
                          />
                          <button className="button is-info" onClick={this.addItem} >
                            Add Notes
                          </button>

                        </form>
                        
                   </section>

             </div>
            
          </div>
        );
    }
  }

  //define a class of handling filter function
  class List extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            filtered: []
        };
        this.handleChange = this.handleChange.bind(this);
        this.delete = this.delete.bind(this);
    }
    
        delete(id){
            this.setState(prevState => ({
                filtered: prevState.filtered.filter(el => el != id )
            }));
        }

        componentDidMount() {
            this.setState({
              filtered: this.props.items
            });
        }

      componentWillReceiveProps(nextProps) {
          this.setState({
            filtered: nextProps.items
          });
      }
    
      handleChange(e) {
          // Variable to hold the original version of the list
        let currentList = [];
            // Variable to hold the filtered list before putting into state
        let newList = [];
            
            // If the search bar isn't empty
        if (e.target.value !== "") {
                // Assign the original list to currentList
          currentList = this.props.items;
                
                // Use .filter() to determine which items should be displayed
                // based on the search terms
          newList = currentList.filter(item => {
                    // change current item to lowercase
            const lc = item.toLowerCase();
                    // change search term to lowercase
            const filter = e.target.value.toLowerCase();
                    // check to see if the current list item includes the search term
                    // If it does, it will be added to newList. Using lowercase eliminates
                    // issues with capitalization in search terms and search content
            return lc.includes(filter);
          });
        } else {
                // If the search bar is empty, set newList to original task list
          newList = this.props.items;
        }
          // Set the filtered state based on what our rules added to newList
        this.setState({
          filtered: newList
        });
      }
    
    render() {
        return (
            <div style={{ marginBottom: '1vmax',marginTop: '1vmax', marginLeft: '2vmax'}}>
                <Child delete={this.delete} filtered={this.state.filtered}/>
                  
            </div>
        )
    }
}
 
 //define a child class so we can hidden search results
class Child extends React.Component{

   delete(id){
       this.props.delete(id);
   }
   
   render(){
      return(
         <div >
           {
              this.props.filtered.map(el=>
                 <li> <h3 onClick={this.delete.bind(this, el)} style={{fontSize: '1.5vmax',}}>{el}  <img  src={iconsdelete} alt="hidden" width='2%' style={{marginLeft: '1vmax',}}/> </h3> </li>
              )
           }
         </div>
      )
   }
}


export default Searchall;



